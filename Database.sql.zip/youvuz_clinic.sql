-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 27, 2021 at 03:24 AM
-- Server version: 10.3.29-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `youvuz_clinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `drid` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `fromid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `uid`, `drid`, `message`, `fromid`) VALUES
(1, 5, 4, 'hello ffrom doctor', 4),
(2, 5, 4, 'hello from user', 5),
(3, 5, 4, 'hello', 4),
(4, 5, 4, 'hi', 5),
(5, 5, 4, 'hi', 5),
(6, 5, 4, 'hi', 5),
(7, 5, 4, 'hi', 5),
(8, 5, 6, 'hi', 5),
(9, 5, 6, 'welcom', 6),
(10, 5, 4, 'hi', 5),
(11, 5, 3, 'hi', 5),
(12, 5, 3, 'hi', 5),
(13, 5, 3, 'hello', 5),
(14, 5, 3, 'welcome', 5),
(15, 5, 3, 'welcome', 5),
(16, 5, 22, 'hi', 5),
(17, 5, 22, 'welcom', 5),
(18, 5, 30, 'hi', 30),
(19, 25, 34, 'hi', 25),
(20, 5, 3, 'ÙŠØ´Ø³ÙŠØ³ÙŠ', 5);

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`id`, `name`, `description`) VALUES
(17, 'Heart Department', 'As the center focus of cardiology, the heart has numerous anatomical features (e.g., atria, ventricles, heart valves) and numerous physiological features (e.g., systole, heart sounds, afterload) that have been encyclopedically documented for many centuries.\r\n\r\nDisorders of the heart lead to heart disease and cardiovascular disease and can lead to a significant number of deaths: cardiovascular disease is the leading cause of death in the United States and caused 24.95% of total deaths in 2008.[16]\r\n\r\nThe primary responsibility of the heart is to pump blood throughout the body. It pumps blood from the body â€” called the systemic circulation â€” through the lungs â€” called the pulmonary circulation â€” and then back out to the body. This means that the heart is connected to and affects the entirety of the body. Simplified, the heart is a circuit of the Circulation.[citation needed] While plenty is known about the healthy heart, the bulk of study in cardiology is in disorders of the heart and restoration, and where possible, of function.'),
(18, 'internal medicine Department', 'Many internists enter into practice following completion of their basic internal medicine training.  These physicians practice â€œgeneral internal medicineâ€ and are commonly referred to as â€œgeneral internists.â€ General internists are equipped to handle the broad and comprehensive spectrum of illnesses that affect adults, and are recognized as experts in diagnosis, in treatment of chronic illness, and in health promotion and disease preventionâ€”they are not limited to one type of medical problem or organ system. General internists are equipped to deal with whatever problem a patient bringsâ€”no matter how common or rare, or how simple or complex. They are specially trained to solve puzzling diagnostic problems and can handle severe chronic illnesses and situations where several different illnesses may strike at the same time. '),
(19, 'Orthopedics ', ' is a medical specialty that focuses on the diagnosis, correction, prevention, and treatment of patients with skeletal deformities - disorders of the bones, joints, muscles, ligaments, tendons, nerves and skin. These elements make up the musculoskeletal system.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `info_id` int(11) DEFAULT NULL,
  `dept_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `type`, `info_id`, `dept_id`, `status`, `mobile`) VALUES
(1, 'admin', 'admin', '1', NULL, NULL, NULL, NULL),
(3, 'DR.osama odat', '123', '2', NULL, 2, 1, NULL),
(4, 'DR.tasneem tawalbeh', '12', '2', NULL, 1, 1, NULL),
(5, 'haneen@gmail.com', '123', '3', 3, NULL, 1, '+962778212429'),
(6, 'DR.shadi alshaikh', '123', '2', 4, 1, 1, '09999999999'),
(23, 'dr.ahmed', '123', '2', NULL, 3, 0, NULL),
(24, 'Haneen', '12', '2', NULL, 3, 0, NULL),
(22, 'dr.adam', '123', '2', NULL, 16, 0, NULL),
(21, 'aaaa@aaa.aaa', '123', '3', 13, NULL, 1, '07788888888'),
(12, 'dr.Mahmoud darras', '12345', '2', 9, 14, 1, '88528552852'),
(13, 'Rahaf', '12345', '3', 10, NULL, 1, '88528552852'),
(14, 'hjaradat36@gmail.com', '123', '3', 11, NULL, 1, '077777899'),
(15, 'admin@a.a', '123', '3', 12, NULL, 1, '09999999999'),
(17, 'DR.hisham nawafleh', '12345', '2', NULL, 1, 1, NULL),
(20, 'hanan', '12345', '2', NULL, 2, 0, NULL),
(18, 'DR.hamzah alhofahi', '1234', '2', NULL, 1, 0, NULL),
(19, 'DR.mohammed zenati', '123456', '2', NULL, 3, 0, NULL),
(25, 'silena@yahoo.com', '123', '3', 14, NULL, 1, '12345'),
(26, 'sara@gmail.com', '12', '3', 15, NULL, 1, '3456789'),
(27, 'dr.salma', '123', '2', NULL, 19, 0, NULL),
(28, 'dr.kareem', '123', '2', NULL, 17, 0, NULL),
(29, 'dr.nada', '123', '2', NULL, 18, 0, NULL),
(30, 'dr.ali', '123', '2', NULL, 19, 0, NULL),
(31, 'dr.laith', '123', '2', NULL, 17, 0, NULL),
(32, 'dr.osama', '123', '2', NULL, 18, 0, NULL),
(33, 'dr.HaneenJaradat', '12', '2', NULL, 17, 0, NULL),
(34, 'dr.SelenaAlish', '12', '2', NULL, 18, 0, NULL),
(35, 'dr.RahafJaradat', '12', '2', NULL, 19, 0, NULL),
(36, 'dr.SaraAlish', '12', '2', NULL, 17, 0, NULL),
(37, 'dr.SewarAlfdawi', '12', '2', NULL, 18, 0, NULL),
(38, 'dr.SaraDhoun', '12', '2', NULL, 19, 0, NULL),
(39, 'admin@a.aa', 'a', '3', 16, NULL, 1, '1'),
(40, 'noha@yahoo.com', '123', '3', 17, NULL, 1, '0000'),
(41, 'sela@yahoo.com', '123', '3', 18, NULL, 1, '12346');

-- --------------------------------------------------------

--
-- Table structure for table `user_booking`
--

CREATE TABLE `user_booking` (
  `id` int(11) NOT NULL,
  `dr_id` int(11) DEFAULT NULL,
  `dept_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_booking`
--

INSERT INTO `user_booking` (`id`, `dr_id`, `dept_id`, `date`, `user_id`, `status`, `note`) VALUES
(1, 4, 1, '2021-04-24 05:28', 5, '5', 'Completed profile'),
(2, 4, 1, '2021-04-24 16:28', 5, '5', 'hi'),
(3, 6, 1, '2021-05-06 09:46', 5, '5', 'fffffff'),
(4, 16, 1, '2021-05-06 10:11', 5, '5', 'hhhh'),
(5, 4, 1, '2021-05-06 10:14', 5, '5', 'hi'),
(6, 6, 1, '2021-05-09 01:11', 5, '2', NULL),
(7, 3, 2, '2021-05-12 04:43', 5, '5', 'HELLO'),
(8, 19, 3, '2021-05-19 21:54', 5, '1', NULL),
(9, 19, 3, '2021-05-19 21:54', 14, '1', NULL),
(10, 7, 2, '2021-05-19 04:17', 5, '1', NULL),
(11, 3, 2, '2021-05-20 10:40', 5, '5', 'hello'),
(12, 4, 1, '2021-05-20 00:57', 5, '1', NULL),
(13, 22, 16, '2021-05-21 19:24', 5, '4', NULL),
(14, 23, 3, '2021-05-21 19:52', 5, '5', 'thisssssss'),
(15, 24, 3, '2021-05-21 19:56', 5, '2', NULL),
(16, 23, 3, '2021-05-23 04:15', 5, '5', 'omf m'),
(17, 28, 17, '2021-05-25 14:07', 5, '1', NULL),
(18, 30, 19, '2021-05-25 16:07', 5, '5', 'allergy from lactose '),
(19, 34, 18, '2021-05-26 19:59', 25, '3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_booking_status`
--

CREATE TABLE `user_booking_status` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_booking_status`
--

INSERT INTO `user_booking_status` (`id`, `name`) VALUES
(1, 'Waiting'),
(2, 'Approve From Doctor'),
(3, 'Need Permissions'),
(4, 'Approved'),
(5, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `birrth_date` varchar(10) DEFAULT NULL,
  `addresses` varchar(255) DEFAULT NULL,
  `phone_number` varchar(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `blood_type` varchar(255) DEFAULT NULL,
  `q1` varchar(255) DEFAULT NULL,
  `q2` varchar(255) DEFAULT NULL,
  `emergency_contact` varchar(255) DEFAULT NULL,
  `contact_number` varchar(11) DEFAULT NULL,
  `relationship` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `first_name`, `last_name`, `gender`, `birrth_date`, `addresses`, `phone_number`, `weight`, `height`, `blood_type`, `q1`, `q2`, `emergency_contact`, `contact_number`, `relationship`) VALUES
(4, 'kjk', 'sss', 'female', '', 'jsjdjs', '07777777', 1, 22, 'B+', 'no', 'no', 'kdkdk', '0888888', 'friends'),
(3, 'haneen', 'jaradat', 'male', '', 'irbid/Jordan', '+9624444444', 68, 173, 'A+', 'no', 'no', '07733333333', '+962778899', 'relatives'),
(5, 'kjk', 'sss', 'female', '', 'jsjdjs', '07777777', 1, 22, 'B+', 'no', 'no', 'kdkdk', '0888888', 'friends'),
(6, '', '', NULL, '', '', '', 0, 0, 'A+', 'no', 'no', '', '', 'relatives'),
(7, 'kjk', 'sss', 'female', '', 'jsjdjs', '0798017813', 1, 22, 'A-', 'no', 'no', 'kdkdk', '0888888', 'friends'),
(8, 'silena', 'mostafa', 'female', '', 'amman', '5725572', 58, 160, 'A+', 'no', 'no', 'haneen', '6252725', 'friends'),
(9, 'silena', 'mostafa', 'female', '', 'amman', '5725572', 58, 160, 'A+', 'no', 'no', 'haneen', '6252725', 'friends'),
(10, 'silena', 'mostafa', 'female', '', 'amman', '5725572', 58, 160, 'A+', 'no', 'no', 'haneen', '6252725', 'friends'),
(11, 'haneen', 'jaradat', 'female', '', 'irbid', '07777777456', 60, 173, 'B+', 'no', 'no', 'kdkdk', '0888888097', 'friends'),
(12, 'haneen', 'jaradat', 'female', '', 'irbid', '07777777456', 60, 173, 'B+', 'no', 'no', 'kdkdk', '0888888097', 'friends'),
(13, 'aaa', 'sssss', 'male', '2021-05-21', 'amman 2', '07777777777', 80, 180, 'A+', 'no', 'no', '0777777777', '08987655678', 'relatives'),
(14, 'selena', 'mostafa', 'female', '12/5/1998', 'amman', '000000', 55, 160, 'A+', 'no', 'no', 'heno', '123', 'friends'),
(15, 'sara', 'ss', 'male', '2021-05-06', 'amman', '234567890', 77, 129, 'A+', 'no', 'no', 'dfghj', '34567', 'relatives'),
(16, 'haneena', 'jaradata', 'female', '2021-05-26', 'jsjdjsq', '07984691581', 601, 221, 'A+', 'no', 'no', 'kdkdka', '08888880971', 'friends'),
(17, 'noha', 'ahmad', 'male', '2021-05-13', 'amman', '000000', 80, 160, 'A+', 'no', 'no', 'haneem', '0000', 'friends'),
(18, 'sela', 'alish', 'female', '12/5/1998', 'amman', '12345', 55, 160, 'A+', 'no', 'no', 'sara', '1234567', 'friends');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Doctor'),
(3, 'Pationt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_booking`
--
ALTER TABLE `user_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_booking_status`
--
ALTER TABLE `user_booking_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `dept`
--
ALTER TABLE `dept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `user_booking`
--
ALTER TABLE `user_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user_booking_status`
--
ALTER TABLE `user_booking_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
